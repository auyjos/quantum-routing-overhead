"""Section 1 explainer: why restricted connectivity costs depth."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle, Circle
import style as S

S.apply()
fig, axes = plt.subplots(1, 3, figsize=(16.0, 4.9),
                         gridspec_kw={"width_ratios": [1.05, 0.72, 1.30]})
for a in axes:
    a.set_axis_off()

MONO = "DejaVu Sans Mono"


def wires(ax, n, x0, x1, labels=True, y0=0.0, dy=1.0):
    for i in range(n):
        y = y0 - i * dy
        ax.plot([x0, x1], [y, y], color=S.INK_SOFT, lw=1.3, zorder=1)
        if labels:
            ax.text(x0 - 0.22, y, f"q{i}", ha="right", va="center",
                    fontsize=12, family=MONO, color=S.INK)


def ctrl(ax, x, y, col=S.INK):
    ax.add_patch(Circle((x, y), 0.085, facecolor=col, edgecolor=col, zorder=4))


def targ(ax, x, y, col=S.INK):
    ax.add_patch(Circle((x, y), 0.17, facecolor=S.PAPER, edgecolor=col,
                        lw=1.7, zorder=4))
    ax.plot([x - 0.17, x + 0.17], [y, y], color=col, lw=1.6, zorder=5)
    ax.plot([x, x], [y - 0.17, y + 0.17], color=col, lw=1.6, zorder=5)


def cx(ax, xc, yc, yt, col=S.INK):
    ax.plot([xc, xc], [yc, yt], color=col, lw=1.7, zorder=3)
    ctrl(ax, xc, yc, col); targ(ax, xc, yt, col)


def swap(ax, x, y1, y2, col=S.C_LINE):
    ax.plot([x, x], [y1, y2], color=col, lw=1.9, zorder=3)
    for y in (y1, y2):
        ax.plot([x - 0.14, x + 0.14], [y - 0.14, y + 0.14], color=col, lw=2.0,
                zorder=5)
        ax.plot([x - 0.14, x + 0.14], [y + 0.14, y - 0.14], color=col, lw=2.0,
                zorder=5)


# ---------- panel A: the logical circuit ------------------------------------
ax = axes[0]
wires(ax, 3, 0.0, 3.4)
cx(ax, 2.0, 0.0, -2.0)
ax.set_xlim(-0.9, 3.6); ax.set_ylim(-3.5, 1.5)
ax.text(-0.75, 1.05, "1 · LOGICAL CIRCUIT", fontsize=12.5, fontweight="bold",
        color=S.INK, ha="left")
ax.text(-0.75, 0.62, "hardware-agnostic — q0 must interact with q2",
        fontsize=11, color=S.INK_SOFT, ha="left")
ax.text(1.75, -2.85, "one two-qubit layer", fontsize=11, color=S.INK_SOFT,
        ha="center", style="italic")

# ---------- panel B: the constraint -----------------------------------------
ax = axes[1]
ax.set_xlim(-0.5, 3.0); ax.set_ylim(-3.5, 1.5)
ax.text(-0.45, 1.05, "2 · COUPLING MAP", fontsize=12.5, fontweight="bold",
        color=S.INK, ha="left")
ax.text(-0.45, 0.62, "q0 and q2 are not adjacent", fontsize=11,
        color=S.INK_SOFT, ha="left")
xs = [0.25, 1.25, 2.25]
ax.plot(xs[:2], [-1.0, -1.0], color=S.C_LINE, lw=2.4, zorder=1)
ax.plot(xs[1:], [-1.0, -1.0], color=S.C_LINE, lw=2.4, zorder=1)
for x, lab in zip(xs, ["q0", "q1", "q2"]):
    ax.add_patch(Circle((x, -1.0), 0.26, facecolor="white",
                        edgecolor=S.C_LINE, lw=2.2, zorder=3))
    ax.text(x, -1.0, lab, ha="center", va="center", fontsize=11, family=MONO,
            color=S.INK, zorder=4)
arc = FancyArrowPatch((xs[0], -0.72), (xs[2], -0.72),
                      connectionstyle="arc3,rad=-0.45", color="#C2413F",
                      lw=1.8, linestyle=(0, (4, 2)), arrowstyle="-", zorder=2)
ax.add_patch(arc)
ax.text(1.25, 0.12, "no direct edge", ha="center", fontsize=11,
        color="#C2413F", fontweight="bold")
ax.text(1.25, -2.15, "the compiler must move a qubit\nbefore the gate can run",
        ha="center", fontsize=11, color=S.INK_SOFT, linespacing=1.5)

# ---------- panel C: the routed circuit -------------------------------------
ax = axes[2]
wires(ax, 3, 0.0, 4.6)
swap(ax, 1.15, 0.0, -1.0)
cx(ax, 2.45, -1.0, -2.0)
swap(ax, 3.65, 0.0, -1.0)
ax.set_xlim(-0.9, 5.5); ax.set_ylim(-3.5, 1.5)
ax.text(-0.75, 1.05, "3 · AFTER ROUTING", fontsize=12.5, fontweight="bold",
        color=S.INK, ha="left")
ax.text(-0.75, 0.62,
        "SWAPs move q0 next to q2, then restore the mapping",
        fontsize=11, color=S.INK_SOFT, ha="left")
for x, lab in ((1.15, "SWAP"), (3.65, "SWAP")):
    ax.text(x, -2.62, lab, ha="center", fontsize=10.5, family=MONO,
            color=S.C_LINE, fontweight="bold")
ax.text(2.45, -2.62, "CX", ha="center", fontsize=10.5, family=MONO,
        color=S.INK, fontweight="bold")
ax.annotate("", xy=(4.35, -3.05), xytext=(0.45, -3.05),
            arrowprops=dict(arrowstyle="-|>", color=S.INK_SOFT, lw=1.4))
ax.text(2.4, -3.30, "more two-qubit layers  →  greater two-qubit depth",
        ha="center", va="top", fontsize=11.5, color=S.INK, fontweight="bold")

fig.suptitle("Restricted connectivity forces extra qubit movement before a "
             "logical interaction can execute",
             fontsize=15, color=S.INK_SOFT, fontweight="normal", y=1.02)
S.save(fig, "fig0_routing_problem")
