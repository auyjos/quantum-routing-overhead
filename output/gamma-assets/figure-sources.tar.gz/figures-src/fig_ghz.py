"""GHZ chain vs GHZ star: interaction shape against coupling shape."""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import style as S

S.apply()
raw = pd.read_csv("raw.csv")

fig = plt.figure(figsize=(16.5, 6.4))
gs = GridSpec(2, 5, figure=fig, width_ratios=[0.85, 1, 1, 1, 0.02],
              height_ratios=[1, 1], wspace=0.30, hspace=0.42)


def draw_chain(ax, col=S.INK):
    xs = np.arange(5)
    ax.plot(xs, [0] * 5, color=col, lw=2.2, zorder=1)
    ax.scatter(xs, [0] * 5, s=170, facecolor="white", edgecolor=col,
               linewidth=2.2, zorder=2)
    ax.set_xlim(-0.8, 4.8); ax.set_ylim(-1.5, 1.5)


def draw_star(ax, col=S.INK):
    edges = [(0, 0, 0, 1), (0, 0, 0, -1), (0, 0, -1.35, 0), (0, 0, 1.35, 0)]
    for x0, y0, x1, y1 in edges:
        ax.plot([x0, x1], [y0, y1], color=col, lw=2.2, zorder=1)
    pts = np.array([[0, 0], [0, 1], [0, -1], [-1.35, 0], [1.35, 0]])
    ax.scatter(pts[:, 0], pts[:, 1], s=170, facecolor="white", edgecolor=col,
               linewidth=2.2, zorder=2)
    ax.scatter([0], [0], s=170, facecolor=col, edgecolor=col, linewidth=2.2,
               zorder=3)
    ax.set_xlim(-2.2, 2.2); ax.set_ylim(-1.7, 1.7)


ROWS = [("ghz_chain", "GHZ Chain", draw_chain,
         "nearest-neighbour\ninteractions"),
        ("ghz_star", "GHZ Star", draw_star,
         "one hub touches\nevery other qubit")]

for r, (fam, label, drawer, blurb) in enumerate(ROWS):
    ax0 = fig.add_subplot(gs[r, 0])
    drawer(ax0)
    ax0.set_axis_off()
    ax0.set_title(label, fontsize=17, pad=10)
    ax0.text(0.5, -0.10, blurb, transform=ax0.transAxes, ha="center",
             va="top", fontsize=10.5, color=S.INK_SOFT, wrap=True)

    for c, lvl in enumerate([0, 1, 3]):
        ax = fig.add_subplot(gs[r, c + 1])
        for topo in ["complete_27", "cairo_heavy_hex_27", "line_27"]:
            sub = raw[(raw.circuit_family == fam) & (raw.topology == topo)
                      & (raw.optimization_level == lvl)]
            g = sub.groupby("logical_qubits").two_qubit_depth_penalty
            med = g.median().reindex(S.SIZES)
            q25 = g.quantile(.25).reindex(S.SIZES)
            q75 = g.quantile(.75).reindex(S.SIZES)
            col = S.TOPO_COLOR[topo]
            base = topo == "complete_27"
            if not base:
                ax.fill_between(S.SIZES, q25, q75, color=col, alpha=0.18, lw=0)
            ax.plot(S.SIZES, med, color=col, lw=1.8 if base else 2.7,
                    linestyle=(0, (5, 3)) if base else "-",
                    marker="" if base else "o", ms=5.2,
                    markerfacecolor=S.PAPER, markeredgewidth=1.9, zorder=3)
        ax.set_ylim(0.55, 5.9)
        ax.set_xticks(S.SIZES)
        S.strip(ax)
        if r == 0:
            ax.set_title(f"optimization level {lvl}", fontsize=12.5,
                         color=S.INK_SOFT, fontweight="bold", pad=9)
        if r == 1:
            ax.set_xlabel("Logical qubits", fontsize=10.5)
        if c == 0:
            ax.set_ylabel("2q depth penalty (×)", fontsize=10.5)
        else:
            ax.tick_params(labelleft=False)
        if r == 0 and c == 2:
            for topo, y in (("cairo_heavy_hex_27", 4.7), ("line_27", 1.0)):
                ax.annotate(S.TOPO_LABEL[topo], xy=(24, y), xytext=(8, 0),
                            textcoords="offset points", va="center",
                            fontsize=12, fontweight="bold",
                            color=S.TOPO_COLOR[topo], annotation_clip=False)
            ax.set_xlim(3, 27)

fig.suptitle("Interaction Structure Matters", fontsize=23, fontweight="bold",
             color=S.INK, y=1.10)
fig.text(0.5, 1.028,
         "Same logical task, same qubit count, same compiler settings — only the shape of the required interactions differs.",
         ha="center", fontsize=12.5, color=S.INK_SOFT)
S.save(fig, "fig4_ghz_chain_vs_star")
