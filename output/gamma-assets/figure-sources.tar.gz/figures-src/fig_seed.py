"""SABRE seed variability at the highest-median-overhead configuration of each
circuit-family / constrained-topology pair. Five fixed seeds per box."""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import style as S

S.apply()
raw = pd.read_csv("raw.csv")
con = raw[raw.topology != "complete_27"]

# select, per (family, topology), the configuration with the highest median
med = con.groupby(["circuit_family", "topology", "logical_qubits",
                   "optimization_level"]).two_qubit_depth_penalty.median() \
         .reset_index()

rows = []
for fam in S.FAMILY_ORDER:
    for topo in ["cairo_heavy_hex_27", "line_27"]:
        sel = med[(med.circuit_family == fam) & (med.topology == topo)]
        b = sel.loc[sel.two_qubit_depth_penalty.idxmax()]
        n, lvl = int(b.logical_qubits), int(b.optimization_level)
        vals = con[(con.circuit_family == fam) & (con.topology == topo)
                   & (con.logical_qubits == n)
                   & (con.optimization_level == lvl)] \
            .two_qubit_depth_penalty.values
        rows.append(dict(fam=fam, topo=topo, n=n, lvl=lvl, vals=vals))

fig, ax = plt.subplots(figsize=(14.6, 6.0))
pos, labels, sublabels = [], [], []
p = 0.0
for i, fam in enumerate(S.FAMILY_ORDER):
    grp = [r for r in rows if r["fam"] == fam]
    for j, r in enumerate(grp):
        pos.append(p + j * 0.62)
        sublabels.append(f"n={r['n']}\nL{r['lvl']}")
    labels.append((p + 0.31, S.FAMILY_LABEL[fam]))
    p += 1.85

for x, r in zip(pos, rows):
    v = r["vals"]
    col = S.TOPO_COLOR[r["topo"]]
    lo, q1, m, q3, hi = (v.min(), np.percentile(v, 25), np.median(v),
                         np.percentile(v, 75), v.max())
    ax.plot([x, x], [lo, hi], color=col, lw=1.6, alpha=0.65, zorder=2)
    for y in (lo, hi):
        ax.plot([x - 0.09, x + 0.09], [y, y], color=col, lw=1.6, alpha=0.65,
                zorder=2)
    ax.add_patch(plt.Rectangle((x - 0.17, q1), 0.34, max(q3 - q1, 0.012),
                               facecolor=col, alpha=0.24, edgecolor=col,
                               linewidth=1.4, zorder=3))
    ax.plot([x - 0.17, x + 0.17], [m, m], color=col, lw=3.0, zorder=5,
            solid_capstyle="butt")
    ax.scatter(np.full(len(v), x) + np.linspace(-0.055, 0.055, len(v)), v,
               s=17, color=col, alpha=0.75, zorder=4, linewidths=0)
    ax.annotate(f"{hi - lo:.2f}", (x, hi), xytext=(0, 8),
                textcoords="offset points", ha="center", fontsize=9,
                color=col, fontweight="bold")

ax.set_xticks(pos)
ax.set_xticklabels(sublabels, fontsize=9.5, color=S.INK_SOFT,
                   family="DejaVu Sans Mono", linespacing=1.35)
for x, lab in labels:
    ax.annotate(lab, (x, 0), xycoords=("data", "axes fraction"),
                xytext=(0, -46), textcoords="offset points", ha="center",
                fontsize=14, fontweight="bold", color=S.INK,
                annotation_clip=False)

ax.axhline(1.0, color=S.C_COMPLETE, lw=1.6, linestyle=(0, (5, 3)), zorder=0)
ax.annotate("Complete = 1×", (ax.get_xlim()[1], 1.0), xytext=(-4, 8),
            textcoords="offset points", ha="right", fontsize=10.5,
            color=S.C_COMPLETE, fontweight="bold")
ax.set_ylabel("Two-qubit depth penalty  (× baseline)", fontsize=12)
ax.set_ylim(0.75, 8.15)
S.strip(ax)

ax.annotate("Heavy-hex", (pos[0], 7.75), fontsize=13, fontweight="bold",
            color=S.C_CAIRO, ha="center")
ax.annotate("Linear", (pos[1], 7.75), fontsize=13, fontweight="bold",
            color=S.C_LINE, ha="center")

fig.suptitle("SABRE Seed Variability", fontsize=22, fontweight="bold",
             color=S.INK, y=1.12, x=0.125, ha="left")
fig.text(0.125, 1.035,
         "Worst configuration per circuit family and map · five fixed seeds "
         "(11, 22, 33, 44, 55) · whiskers = min/max, box = IQR, thick rule = median · "
         "number above each box is the max−min spread",
         ha="left", fontsize=11.5, color=S.INK_SOFT)
fig.text(0.5, -0.16,
         "Stochastic routing produces different compiled circuits from identical logical input, "
         "so every configuration is transpiled under repeated fixed seeds. In every family/map pair the worst-median configuration falls at optimization level 0.",
         ha="center", fontsize=11.5, color=S.INK)
S.save(fig, "fig6_seed_variability")
