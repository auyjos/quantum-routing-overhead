"""Compiler optimization trade-off: routing quality against local compile time."""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import style as S

S.apply()
can = pd.read_csv("raw.csv")                    # canonical routing metrics
pool = pd.read_csv("timingpool.csv")            # canonical + 2 rotated repeats

LEVELS = [0, 1, 3]
MARK = {0: "o", 1: "s", 3: "D"}
SIZE = {0: 105, 1: 115, 3: 115}

fig, (ax, ax2) = plt.subplots(1, 2, figsize=(14.4, 6.2),
                              gridspec_kw={"width_ratios": [1.18, 1]})

# ---- left: quality vs time -------------------------------------------------
for topo in S.TOPO_ORDER:
    col = S.TOPO_COLOR[topo]
    xs, ys = [], []
    for lvl in LEVELS:
        q = can[(can.topology == topo) & (can.optimization_level == lvl)] \
            .two_qubit_depth_penalty
        t = pool[(pool.topology == topo) & (pool.optimization_level == lvl)] \
            .compile_time_seconds * 1000
        x, y = t.median(), q.median()
        xs.append(x); ys.append(y)
        ax.plot([t.quantile(.25), t.quantile(.75)], [y, y], color=col, lw=2.0,
                alpha=0.45, solid_capstyle="butt", zorder=2)
        ax.plot([x, x], [q.quantile(.25), q.quantile(.75)], color=col, lw=2.0,
                alpha=0.45, solid_capstyle="butt", zorder=2)
        ax.scatter([x], [y], s=SIZE[lvl], marker=MARK[lvl], color=col,
                   edgecolor=S.PAPER, linewidth=1.4, zorder=4)
        dx, dy, ha = {"complete_27": (0, 13, "center"),
                      "cairo_heavy_hex_27": (0, 13, "center"),
                      "line_27": (0, -22, "center")}[topo]
        ax.annotate(f"L{lvl}", (x, y), xytext=(dx, dy),
                    textcoords="offset points", ha=ha, fontsize=11,
                    fontweight="bold", color=col, zorder=5)
    ax.plot(xs, ys, color=col, lw=1.5, alpha=0.55, zorder=1)
    ax.annotate(S.TOPO_LABEL[topo], (xs[-1], ys[-1]), xytext=(10, -12),
                textcoords="offset points", fontsize=13, fontweight="bold",
                color=col)

ax.set_xscale("log")
ax.set_xlabel("Median compilation time  (ms, log scale)", fontsize=12)
ax.set_ylabel("Median two-qubit depth penalty  (× baseline)", fontsize=12)
ax.set_title("Compiler Optimization Trade-Off", fontsize=19, pad=30, loc="left")
ax.text(0, 1.045, "Does spending more compiler time produce a better routed circuit?",
        transform=ax.transAxes, fontsize=12.5, color=S.INK_SOFT)
ax.set_ylim(0.55, 5.4)
ax.set_xlim(1.6, 200)
ax.set_xticks([2, 5, 10, 20, 50, 100])
ax.get_xaxis().set_major_formatter(plt.ScalarFormatter())
ax.axhline(1.0, color=S.C_COMPLETE, lw=1.6, linestyle=(0, (5, 3)), zorder=0)
S.strip(ax, grid_axis="both")

# ---- right: per-family quality by level ------------------------------------
w = 0.26
xpos = np.arange(len(S.FAMILY_ORDER))
for i, lvl in enumerate(LEVELS):
    vals = [can[(can.circuit_family == f) & (can.topology != "complete_27")
                & (can.optimization_level == lvl)].two_qubit_depth_penalty.median()
            for f in S.FAMILY_ORDER]
    shade = {0: 0.95, 1: 0.62, 3: 0.32}[lvl]
    ax2.bar(xpos + (i - 1) * w, vals, width=w * 0.9,
            color=S.INK, alpha=shade, edgecolor="none",
            label=f"level {lvl}")
    for x, v in zip(xpos + (i - 1) * w, vals):
        ax2.annotate(f"{v:.2f}", (x, v), xytext=(0, 4),
                     textcoords="offset points", ha="center", fontsize=8.5,
                     color=S.INK_SOFT)

ax2.set_xticks(xpos)
ax2.set_xticklabels([S.FAMILY_LABEL[f] for f in S.FAMILY_ORDER], fontsize=11)
ax2.set_ylabel("Median 2q depth penalty (×)", fontsize=11.5)
ax2.set_title("Stronger presets lower the penalty for every family except the chain",
              fontsize=12.5, pad=30, loc="left", color=S.INK_SOFT,
              fontweight="normal")
ax2.text(0, 1.045, "Both constrained maps pooled, by optimization level",
         transform=ax2.transAxes, fontsize=12.5, color=S.INK)
ax2.axhline(1.0, color=S.C_COMPLETE, lw=1.6, linestyle=(0, (5, 3)), zorder=0)
ax2.set_ylim(0, 5.0)
ax2.legend(fontsize=10.5, loc="upper right", ncol=3, columnspacing=1.0,
           handlelength=1.2)
S.strip(ax2)

fig.text(0.5, -0.10,
         "Quality: canonical run, 120 observations per topology×level (4 families × 6 sizes × 5 seeds).   "
         "Time: 360 observations (same grid × 3 process repeats).\n"
         "Bars are IQRs describing heterogeneous distributions, not uncertainty intervals.   "
         "Timing is local compiler wall-clock on the test machine, not QPU performance.",
         ha="center", fontsize=10.5, color=S.INK_SOFT, linespacing=1.6)
fig.subplots_adjust(wspace=0.30)
S.save(fig, "fig5_optimization_tradeoff")
