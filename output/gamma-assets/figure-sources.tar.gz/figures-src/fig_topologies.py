import json, math
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import style as S

S.apply()
topo = {t["topology"]: t for t in json.load(open("topo.json"))}


def layout(name, G):
    if name == "line_27":
        return {i: (i, 0.0) for i in range(27)}
    if name == "complete_27":
        return {i: (math.cos(2 * math.pi * i / 27), math.sin(2 * math.pi * i / 27))
                for i in range(27)}
    # heavy-hex: planar embedding reads as hexagons; fall back to kamada-kawai
    try:
        pos = nx.planar_layout(G)
        pos = nx.kamada_kawai_layout(G, pos=pos)
    except Exception:
        pos = nx.kamada_kawai_layout(G)
    return pos


META = {
    "complete_27": ("Complete", "idealised baseline", S.C_COMPLETE),
    "cairo_heavy_hex_27": ("Heavy-hex", "hardware-representative", S.C_CAIRO),
    "line_27": ("Linear", "restrictive topology", S.C_LINE),
}

fig, axes = plt.subplots(1, 3, figsize=(15.5, 5.4))
for ax, name in zip(axes, S.TOPO_ORDER):
    t = topo[name]
    G = nx.Graph()
    G.add_nodes_from(range(27))
    G.add_edges_from([tuple(e) for e in t["edge_list"]])
    pos = layout(name, G)

    label, sub, col = META[name]
    ew = {"complete_27": 0.28, "cairo_heavy_hex_27": 1.7, "line_27": 2.0}[name]
    ea = {"complete_27": 0.42, "cairo_heavy_hex_27": 0.9, "line_27": 0.9}[name]
    ns = {"complete_27": 100, "cairo_heavy_hex_27": 118, "line_27": 62}[name]
    lw = {"complete_27": 1.7, "cairo_heavy_hex_27": 1.8, "line_27": 1.4}[name]
    nx.draw_networkx_edges(G, pos, ax=ax, edge_color=col, width=ew, alpha=ea)
    nx.draw_networkx_nodes(G, pos, ax=ax, node_size=ns, node_color="white",
                           edgecolors=col, linewidths=lw)

    ax.set_title(label, fontsize=17, color=S.INK, pad=16, loc="center")
    ax.text(0.5, 1.005, sub.upper(), transform=ax.transAxes, ha="center",
            va="bottom", fontsize=9.5, color=col, fontweight="bold",
            family="DejaVu Sans")
    stats = (f"couplings  {t['undirected_edges']}\n"
             f"degree     {t['min_degree']}–{t['max_degree']}\n"
             f"diameter   {t['diameter']}\n"
             f"mean path  {t['average_shortest_path_length']:.2f}")
    ax.text(0.5, -0.06, stats, transform=ax.transAxes, ha="center", va="top",
            fontsize=11, color=S.INK_SOFT, family="DejaVu Sans Mono",
            linespacing=1.65)
    ax.set_axis_off()
    if name == "line_27":
        ax.set_ylim(-9.5, 9.5)
    ax.margins(0.06)

fig.suptitle("27 physical qubits, three coupling maps",
             fontsize=13.5, color=S.INK_SOFT, fontweight="normal", y=1.05)
fig.text(0.5, -0.19,
         "Undirected coupling graphs as saved by the benchmark. No calibration or "
         "gate-direction data is used.",
         ha="center", fontsize=10, color=S.INK_SOFT)
S.save(fig, "fig1_topologies")
