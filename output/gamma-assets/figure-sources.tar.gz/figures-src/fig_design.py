"""Section 2: controlled experiment design — circuit families and the grid."""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch
from matplotlib.gridspec import GridSpec
import style as S

S.apply()
MONO = "DejaVu Sans Mono"

fig = plt.figure(figsize=(16.0, 6.6))
gs = GridSpec(2, 4, figure=fig, height_ratios=[1.0, 0.62], hspace=0.55,
              wspace=0.18)


def node(ax, x, y, filled=False, col=S.INK, r=0.15):
    ax.add_patch(Circle((x, y), r, facecolor=col if filled else "white",
                        edgecolor=col, lw=2.0, zorder=3))


def qft(ax):
    n = 6
    xs = np.arange(n) * 0.0
    ys = -np.arange(n) * 0.55
    for i in range(n):
        ax.plot([-0.05, 2.6], [ys[i], ys[i]], color=S.INK_SOFT, lw=1.0)
    # all-to-all long-range arcs
    k = 0
    for i in range(n):
        for j in range(i + 1, n):
            k += 1
            if k % 2:
                continue
            x = 0.18 + 0.16 * k
            ax.plot([x, x], [ys[i], ys[j]], color=S.C_CAIRO, lw=1.0, alpha=0.55)
            node(ax, x, ys[i], True, S.C_CAIRO, 0.045)
            node(ax, x, ys[j], False, S.C_CAIRO, 0.075)
    ax.set_xlim(-0.4, 2.7); ax.set_ylim(-3.2, 0.5)


def chain(ax):
    xs = np.linspace(0.1, 2.5, 6)
    ax.plot(xs, [-1.3] * 6, color=S.INK, lw=2.0, zorder=1)
    for x in xs:
        node(ax, x, -1.3)
    ax.set_xlim(-0.4, 2.7); ax.set_ylim(-3.2, 0.5)


def star(ax):
    cx, cy = 1.3, -1.35
    pts = [(cx, cy + 0.95), (cx, cy - 0.95), (cx - 1.05, cy), (cx + 1.05, cy),
           (cx - 0.78, cy + 0.7), (cx + 0.78, cy - 0.7)]
    for x, y in pts:
        ax.plot([cx, x], [cy, y], color=S.INK, lw=1.8, zorder=1)
        node(ax, x, y)
    node(ax, cx, cy, True)
    ax.set_xlim(-0.4, 3.0); ax.set_ylim(-3.2, 0.5)


def su2(ax):
    n = 6
    ys = -np.arange(n) * 0.5 - 0.15
    for i in range(n):
        ax.plot([-0.05, 2.6], [ys[i], ys[i]], color=S.INK_SOFT, lw=1.0)
    for rep, x0 in enumerate([0.30, 1.25, 2.20]):
        for i in range(n):
            ax.add_patch(FancyBboxPatch((x0 - 0.30, ys[i] - 0.10), 0.20, 0.20,
                                        boxstyle="round,pad=0.02",
                                        facecolor="white", edgecolor=S.INK_SOFT,
                                        lw=1.1, zorder=3))
        for i in range(n):
            j = (i + 1) % n
            if j == 0:
                continue
            x = x0 + 0.055 * i
            ax.plot([x, x], [ys[i], ys[j]], color=S.C_LINE, lw=1.1, alpha=0.8)
            node(ax, x, ys[i], True, S.C_LINE, 0.04)
            node(ax, x, ys[j], False, S.C_LINE, 0.065)
    ax.set_xlim(-0.4, 2.7); ax.set_ylim(-3.2, 0.5)


FAMS = [("QFT", qft, "dense, long-range interactions"),
        ("GHZ Chain", chain, "local, sequential:  q0—q1—q2—…"),
        ("GHZ Star", star, "one hub interacts with all others"),
        ("EfficientSU2", su2, "circular entangling layers, repeated")]

for c, (name, drawer, blurb) in enumerate(FAMS):
    ax = fig.add_subplot(gs[0, c])
    drawer(ax)
    ax.set_axis_off()
    ax.set_title(name, fontsize=16, pad=12)
    ax.text(0.5, -0.02, blurb, transform=ax.transAxes, ha="center", va="top",
            fontsize=10.5, color=S.INK_SOFT)

# ---- the grid strip ---------------------------------------------------------
ax = fig.add_subplot(gs[1, :])
ax.set_axis_off()
ax.set_xlim(0, 1); ax.set_ylim(0, 1)

CELLS = [("4 circuit\nfamilies", "QFT · GHZ Chain\nGHZ Star · EfficientSU2"),
         ("6 logical\nsizes", "4 · 8 · 12\n16 · 20 · 24"),
         ("3 hardware\ntopologies", "Complete · Heavy-hex\nLinear  (27 qubits each)"),
         ("3 optimization\nlevels", "0 · 1 · 3"),
         ("5 fixed\nseeds", "11 · 22 · 33\n44 · 55")]

x = 0.0
w = 1.0 / len(CELLS)
for i, (head, body) in enumerate(CELLS):
    ax.add_patch(FancyBboxPatch((x + 0.010, 0.34), w - 0.020, 0.56,
                                boxstyle="round,pad=0.010,rounding_size=0.02",
                                facecolor="white", edgecolor=S.RULE, lw=1.2))
    ax.text(x + w / 2, 0.755, head, ha="center", va="center", fontsize=12.5,
            fontweight="bold", color=S.INK, linespacing=1.4)
    ax.text(x + w / 2, 0.47, body, ha="center", va="center", fontsize=9.5,
            color=S.INK_SOFT, family=MONO, linespacing=1.6)
    if i < len(CELLS) - 1:
        ax.text(x + w, 0.62, "×", ha="center", va="center",
                fontsize=15, color=S.INK_SOFT)
    x += w

ax.text(0.5, 0.15, "=   1,080 successful compilations   ·   Qiskit 2.5.1   ·   "
                   "common rz, sx, x, cx basis",
        ha="center", va="center", fontsize=13.5, fontweight="bold", color=S.INK)
ax.text(0.5, 0.00,
        "Independent variable: hardware connectivity.   Controlled: circuit instance, "
        "physical-qubit count, basis gates, optimization level, transpiler seed.",
        ha="center", va="center", fontsize=10.5, color=S.INK_SOFT)

fig.suptitle("Controlled Experiment", fontsize=22, fontweight="bold",
             color=S.INK, y=1.03)
S.save(fig, "fig7_experiment_design")
