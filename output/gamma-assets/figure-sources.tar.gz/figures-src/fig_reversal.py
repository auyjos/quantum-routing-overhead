"""Neither sparse topology wins: the ordering reverses by circuit family."""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import style as S

S.apply()
raw = pd.read_csv("raw.csv")

fig, axes = plt.subplots(1, 3, figsize=(15.0, 5.4), sharey=True)
PANELS = [(None, "all levels pooled"), (1, "optimization level 1"),
          (3, "optimization level 3")]

for ax, (lvl, sub) in zip(axes, PANELS):
    d = raw if lvl is None else raw[raw.optimization_level == lvl]
    for i, fam in enumerate(S.FAMILY_ORDER):
        vals = {}
        for topo in ["cairo_heavy_hex_27", "line_27"]:
            vals[topo] = d[(d.circuit_family == fam)
                           & (d.topology == topo)].two_qubit_depth_penalty.median()
        y = len(S.FAMILY_ORDER) - 1 - i
        lo_t = min(vals, key=vals.get)
        ax.plot([vals["cairo_heavy_hex_27"], vals["line_27"]], [y, y],
                color=S.RULE, lw=3.0, zorder=1, solid_capstyle="round")
        for topo in ["cairo_heavy_hex_27", "line_27"]:
            ax.scatter([vals[topo]], [y], s=170, color=S.TOPO_COLOR[topo],
                       zorder=3, edgecolor=S.PAPER, linewidth=1.6)
        hi_t = max(vals, key=vals.get)
        if abs(vals[hi_t] - vals[lo_t]) < 1e-9:
            ax.annotate(f"{vals[lo_t]:.2f}", (vals[lo_t], y), xytext=(0, -23),
                        textcoords="offset points", ha="center", fontsize=10,
                        color=S.INK_SOFT, fontweight="bold")
        else:
            ax.annotate(f"{vals[lo_t]:.2f}", (vals[lo_t], y), xytext=(-13, -5),
                        textcoords="offset points", ha="right", fontsize=10,
                        color=S.TOPO_COLOR[lo_t], fontweight="bold")
            ax.annotate(f"{vals[hi_t]:.2f}", (vals[hi_t], y), xytext=(13, -5),
                        textcoords="offset points", ha="left", fontsize=10,
                        color=S.TOPO_COLOR[hi_t], fontweight="bold")

    ax.set_yticks(range(len(S.FAMILY_ORDER)))
    ax.set_yticklabels([S.FAMILY_LABEL[f] for f in reversed(S.FAMILY_ORDER)],
                       fontsize=13, color=S.INK)
    ax.set_ylim(-0.75, 3.6)
    ax.set_xlim(0.45, 4.6)
    ax.axvline(1.0, color=S.C_COMPLETE, lw=1.5, linestyle=(0, (5, 3)), zorder=0)
    ax.set_title(sub, fontsize=13, color=S.INK_SOFT, pad=12)
    ax.set_xlabel("Median two-qubit depth penalty (×)", fontsize=11)
    S.strip(ax, grid_axis="x")

axes[0].annotate("Heavy-hex", (3.192, 3), xytext=(0, 20),
                 textcoords="offset points", ha="center", fontsize=12,
                 fontweight="bold", color=S.C_CAIRO)
axes[0].annotate("Linear", (2.691, 3), xytext=(-6, 20),
                 textcoords="offset points", ha="right", fontsize=12,
                 fontweight="bold", color=S.C_LINE)

fig.suptitle("Neither sparse topology wins outright",
             fontsize=21, fontweight="bold", color=S.INK, y=1.135)
fig.text(0.5, 1.055,
         "QFT stays cheaper on the line; circular EfficientSU2 stays cheaper on heavy-hex. The reversal survives when the confounded level 0 is dropped.",
         ha="center", fontsize=12, color=S.INK_SOFT)
fig.subplots_adjust(wspace=0.08)
S.save(fig, "fig8_topology_reversal")
