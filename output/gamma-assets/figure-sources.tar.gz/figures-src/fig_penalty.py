"""Primary results grid: penalty vs logical size, faceted by circuit family
(columns) and Qiskit optimization level (rows).

Each point is the median of the 5 fixed transpiler seeds for that exact
configuration; each band is the IQR of those same 5 seeds. Nothing is pooled
across optimization levels inside a panel.
"""
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import style as S

S.apply()
raw = pd.read_csv("raw.csv")

METRIC = sys.argv[1] if len(sys.argv) > 1 else "two_qubit_depth_penalty"
fname, title, ylab = {
    "two_qubit_depth_penalty": (
        "fig2_two_qubit_depth_penalty",
        "Two-Qubit Depth Penalty vs. Logical Qubit Count",
        "Two-qubit depth penalty  (× baseline)"),
    "two_qubit_count_penalty": (
        "fig3_two_qubit_count_penalty",
        "Two-Qubit Gate-Count Penalty vs. Logical Qubit Count",
        "Two-qubit count penalty  (× baseline)"),
}[METRIC]

LEVELS = [0, 1, 3]
fig, axes = plt.subplots(len(LEVELS), 4, figsize=(17.5, 11.4),
                         sharey=True, sharex=True)

ymax = 0.0
for r, lvl in enumerate(LEVELS):
    for c, fam in enumerate(S.FAMILY_ORDER):
        ax = axes[r, c]
        for topo in S.TOPO_ORDER:
            sub = raw[(raw.circuit_family == fam) & (raw.topology == topo)
                      & (raw.optimization_level == lvl)]
            g = sub.groupby("logical_qubits")[METRIC]
            med = g.median().reindex(S.SIZES)
            q25 = g.quantile(0.25).reindex(S.SIZES)
            q75 = g.quantile(0.75).reindex(S.SIZES)
            col = S.TOPO_COLOR[topo]
            base = topo == "complete_27"
            if not base:
                ax.fill_between(S.SIZES, q25, q75, color=col, alpha=0.18,
                                linewidth=0)
            ax.plot(S.SIZES, med, color=col,
                    linewidth=1.9 if base else 2.7,
                    linestyle=(0, (5, 3)) if base else "-",
                    marker="" if base else "o", markersize=5.4,
                    markerfacecolor=S.PAPER, markeredgewidth=1.9, zorder=3)
            ymax = max(ymax, float(np.nanmax(q75.values)))

        if r == 0:
            ax.set_title(S.FAMILY_LABEL[fam], fontsize=16, pad=14)
        if r == len(LEVELS) - 1:
            ax.set_xlabel("Logical qubits", fontsize=11)
        ax.set_xticks(S.SIZES)
        S.strip(ax)

    axes[r, 0].set_ylabel(ylab if r == 1 else "", fontsize=12.5)
    axes[r, 0].text(-0.30, 0.5, f"optimization\nlevel {lvl}",
                    transform=axes[r, 0].transAxes, rotation=0, ha="right",
                    va="center", fontsize=13, fontweight="bold", color=S.INK,
                    linespacing=1.5)

axes[0, 0].set_ylim(0.55, ymax * 1.08)

# direct labels, no legend -- placed on the top-right panel
lab_ax = axes[0, 3]
for topo in S.TOPO_ORDER:
    sub = raw[(raw.circuit_family == S.FAMILY_ORDER[-1])
              & (raw.topology == topo) & (raw.optimization_level == 0)]
    y = sub[sub.logical_qubits == 24][METRIC].median()
    lab_ax.annotate(S.TOPO_LABEL[topo], xy=(24, y), xytext=(7, 0),
                    textcoords="offset points", va="center", ha="left",
                    fontsize=13, fontweight="bold", color=S.TOPO_COLOR[topo],
                    annotation_clip=False)
lab_ax.set_xlim(3, 27.5)

fig.suptitle(title, fontsize=23, fontweight="bold", color=S.INK, y=0.985)
fig.text(0.5, 0.947,
         "penalty  =  constrained-topology value  ÷  matched complete-connectivity value  "
         "(same circuit, size, level, seed and basis)",
         ha="center", fontsize=12.5, color=S.INK_SOFT)
fig.text(0.5, 0.925,
         "point = median of the 5 fixed transpiler seeds   ·   band = IQR of those 5 seeds   ·   "
         "Complete is the 1× denominator by construction",
         ha="center", fontsize=11.5, color=S.INK_SOFT)
fig.subplots_adjust(wspace=0.09, hspace=0.20, top=0.872, left=0.10)
S.save(fig, fname)
